# Shot Baseline 实验汇总

运行 ID: penPangu-Embedded-1B_gsm8k_cot_8shot
总记录数: 1

| run_id | mode | dataset | subset | model | avg_num_shots | count | acc_numeric | em_string | contains | token_f1 | acc_tol_1e-4 | acc_tol_1e-3 | acc_tol_1e-2 | relerr_mean | relerr_median | total_time_s | avg_latency_s | avg_in_tokens | avg_out_tokens | avg_tokpersec |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| penPangu-Embedded-1B_gsm8k_cot_8shot | cot | openai/gsm8k | main | openPangu-Embedded-1B-V1.1 | 8.0 | 10 | 0.8000 | 0.8000 | 0.8000 | 0.8000 | 0.8000 | 0.8000 | 0.8000 | 16.616667 | 0.000000 | 185.354 | 18.535 | 1301.0 | 187.8 | 9.76 |
